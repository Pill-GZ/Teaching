#################################################
#  FLOW CONTROL
#################################################

#####  FOR LOOP

# DISPLAY EXAMPLE 1

# Compare running times between vectorized operation and for loop
n = 2000000;
x = 1:n; y = rep(0, n); # y stores the output
## 1. for loop
start = proc.time()[3];
  for(i in 1:n){
    y[i] = x[i]^2;
  }
time.for = proc.time()[3] - start;
## 2. vectorized
start = proc.time()[3];
  y = x^2;
time.vec = proc.time()[3] - start;
## comparison
print(c(time.for, time.vec));


#####  APPLY()

# Compare running times between apply and for loop
set.seed(2015);
n = 2000; # Don't try n in larger orders
A = matrix(runif(n^2), c(n, n)); b = rep(0, n);
A = round(A, 3);
## 1. for loop
start = proc.time()[3];
  for(i in 1:n){
    b[i] = sum(A[i, ]^2);
  }
time.for = proc.time()[3] - start;
## 2. apply
start = proc.time()[3];
  b = apply(A, 1, function(x) sum(x^2)); # use inline function
time.apply = proc.time()[3] - start;
## 3. vectorized(not always available)
start = proc.time()[3];
  b = A^2 %*% rep(1, n);
time.vec = proc.time()[3] - start;
## compare
print(c(time.for, time.apply, time.vec));


##### Monte Carlo simulation:
n = 100; R = 2000; # 100 light bulbs and 2000 simulation rounds
q = 0.05; # on to off(1 to 0)
p = 0.10; # off to on(0 to 1)
LightBulbs = as.integer(rep(1, n)); # 1 = lighted up; 0 = dead
LightUpCounts = rep(0, n); # corresponding to 100 light bulbs
## ??
## (Continue to write the simulation)
## ??



#################################################
#  DATA INPUT/OUTPUT
#################################################

#####   Input: read.table

# read a test table
test.input.table = read.table('test_input_table.txt', sep=',', header=TRUE, fill=TRUE, stringsAsFactors = FALSE);
print(test.input.table);

# read a line using readLines
Line_1 = readLines('test_input_table.txt', 1);
print(Line_1);


#  Read HW1 data with read.table
dt = read.table('MERGED1996_PP.csv', header=TRUE, sep=',', fill=TRUE, stringsAsFactors=FALSE);
# (then...)
# dt1 = with(dt, cbind(INSTNM, CITY, STABBR, CONTROL, UGDS));
# (and what ever that follows...)

#####   Output: write.table

# output a table
test.output.table = matrix(1:9, c(3,3));
# compare files:
## version 1:
write.table(test.output.table, './test_output_table.txt');
## version 2:
write.table(test.output.table, './test_output_table.txt', sep=',', row.names=FALSE, col.names=FALSE);

# output a table with sink
test.output.table = matrix(1:9, c(3,3));
sink('./test_output_table_2.txt');
## ??
## (Excercise: replace this part with your own code to output the matrix into file.)
## ??
sink();

#################################################
#  SIMPLE PLOTTING
#################################################

# Plotting
# 1. Plot vectors
set.seed(2015);
x_vec = seq(0.1, 1, length.out = 20);
y_vec = 5*x_vec + rnorm(20);
plot(x=x_vec, y=y_vec, type='b');

# 2. Plot functions
# Plot a function directly from its analytical expression
par(mfrow=c(1, 3)); # Partition the screen
plot_function = function(x) x+sin(x);
# Method 1:
curve(x+sin(x), from=-pi, to=pi);
# Method 2:
curve(plot_function, from=-pi, to=pi);
# Method 3:
plot(plot_function, from=-pi, to=pi);

# 3. Output figures
# Plot to file
pdf('./test_output_figure.pdf');
#jpeg('./test_output_figure.jpg');
#x11();
curve(x+sin(x), from=-pi, to=pi);
curve(x^2+cos(x), from=-pi, to=pi);
dev.off();

