########################################################
##### Solution 1
##### Monte Carlo simulation:
########################################################

n = 100; R = 2000; # 100 light bulbs and 2000 simulation rounds
q = 0.05; # on to off(1 to 0)
p = 0.10; # off to on(0 to 1)
LightBulbs = as.integer(rep(1, n)); # 1 = lighted up; 0 = dead
LightUpCounts = rep(0, n); # corresponding to 100 light bulbs
# begin iteration
set.seed(2015);
for (R_ind in 1:R){
  new_LightBulbs = as.integer(rep(1, n)); # WHY DO WE NEED THIS?
	if( any(LightBulbs==1) ){
		new_LightBulbs[LightBulbs==1] = rbinom(n=sum(LightBulbs==1), size=1, prob=1-q);
	}
	if( any(LightBulbs==0) ){
		new_LightBulbs[LightBulbs==0] = rbinom(n=sum(LightBulbs==0), size=1, prob=p);
	}
  LightBulbs = new_LightBulbs;
	LightUpCounts = LightUpCounts + LightBulbs;
}
LightUpProportions = LightUpCounts / R;
cat(paste('mean=', round(mean(LightUpProportions), 3), '  se=', round(sd(LightUpProportions)/sqrt(n), 3)), '\n');
# The mean should be approximately p/(p+q) from stochastic processes theory.


########################################################
## Extension: 3-status case
########################################################

# Three status: 1, 2, and 3
# Transition probabilities from i to j: p_ij
# Set parameters, consider the special case that p_ij=p_ji
p_12=0.1; p_13=0.2;
p_21=0.1; p_23=0.3;
p_31=0.2; p_32=0.3;

# Now many things are similar:
n = 100; R = 5000; BurnIn=2000; # 100 light bulbs and 5000 simulation rounds, with 2000 burn-in rounds.
LightBulbs = as.integer(rep(1, n)); # Let's start with all 1 status this time.
LightUpCounts = array(0, c(3, n)); # Now we need to record the counts for all 3 status respectively
# begin iteration
set.seed(2015);
for (R_ind in 1:(BurnIn+R)){
  new_LightBulbs = as.integer(rep(0, n));
  if( any(LightBulbs==1) ){
    new_LightBulbs[LightBulbs==1] = as.vector( (1:3) %*% rmultinom(sum(LightBulbs==1), 1, c(1-p_12-p_13, p_12, p_13)) );
  }
  if( any(LightBulbs==2) ){
    new_LightBulbs[LightBulbs==2] = as.vector( (1:3) %*% rmultinom(sum(LightBulbs==2), 1, c(p_21, 1-p_21-p_23, p_23)) );
  }
  if( any(LightBulbs==3) ){
    new_LightBulbs[LightBulbs==3] = as.vector( (1:3) %*% rmultinom(sum(LightBulbs==3), 1, c(p_31, p_32, 1-p_31-p_32)) );
  }
  LightBulbs = new_LightBulbs
  
  if(R_ind > BurnIn)
  for(i in 1:3){
    LightUpCounts[i, ] = LightUpCounts[i, ] + (LightBulbs==i);
  }
  
}

LightUpProportions = LightUpCounts / R;

Report = cbind( apply(LightUpProportions, 1, mean), apply(LightUpProportions, 1, sd) );
Report[, 2] = Report[, 2] / sqrt(n); # standard error
print(round(Report, 3));



########################################################
##### Solution 2
##### Output a table with sink
########################################################

test.output.table = matrix(1:9, c(3,3));
sink('./test_output_table_2.txt');
	for(i in 1:3){
	  cat( test.output.table[i, ], sep=',' ); cat('\n');
	}
	cat('\n');
sink();