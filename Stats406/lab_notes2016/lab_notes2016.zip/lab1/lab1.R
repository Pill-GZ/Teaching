test = 1:10
print(test)
